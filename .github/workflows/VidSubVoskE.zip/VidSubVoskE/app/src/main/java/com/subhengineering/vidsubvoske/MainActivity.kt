package com.subhengineering.vidsubvoske

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var cardModel: MaterialCardView
    private lateinit var tvModelStatus: TextView
    private lateinit var progressModel: ProgressBar
    private lateinit var btnDownload: MaterialButton
    private lateinit var btnImport: MaterialButton
    private lateinit var tvStatus: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvTranscript: TextView
    private lateinit var scroll: NestedScrollView
    private lateinit var btnRecord: MaterialButton

    private var modelBusy = false
    private var wantFloating = false
    private lateinit var btnFloating: MaterialButton

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasMicPermission()) askCapturePermission()
            else toast("Audio permission is needed to capture sound.")
        }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, RecordService::class.java)
                    .setAction(RecordService.ACTION_START)
                    .putExtra(RecordService.EXTRA_CODE, r.resultCode)
                    .putExtra(RecordService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
            } else {
                toast("Recording cancelled.")
            }
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) installModel { importFrom(uri) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        cardModel = findViewById(R.id.cardModel)
        tvModelStatus = findViewById(R.id.tvModelStatus)
        progressModel = findViewById(R.id.progressModel)
        btnDownload = findViewById(R.id.btnDownload)
        btnImport = findViewById(R.id.btnImport)
        tvStatus = findViewById(R.id.tvStatus)
        tvTimer = findViewById(R.id.tvTimer)
        tvTranscript = findViewById(R.id.tvTranscript)
        scroll = findViewById(R.id.scrollTranscript)
        btnRecord = findViewById(R.id.btnRecord)

        btnRecord.setOnClickListener { onRecordClicked() }
        btnFloating = findViewById(R.id.btnFloating)
        btnFloating.setOnClickListener { toggleFloating() }
        findViewById<MaterialButton>(R.id.btnCopy).setOnClickListener { copyText() }
        findViewById<MaterialButton>(R.id.btnNew).setOnClickListener { newSession() }
        findViewById<MaterialButton>(R.id.btnRecordings).setOnClickListener {
            startActivity(Intent(this, RecordingsActivity::class.java))
        }
        btnDownload.setOnClickListener { installModel { downloadModel() } }
        btnImport.setOnClickListener {
            importLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed",
                "application/octet-stream"))
        }

        refreshModelCard()
        observeState()
    }

    override fun onResume() {
        super.onResume()
        if (wantFloating && Settings.canDrawOverlays(this)) {
            wantFloating = false
            startFloating()
        }
        updateFloatingButton()
    }

    // ---------- Floating button ----------

    private fun updateFloatingButton(on: Boolean = OverlayService.running) {
        btnFloating.text = getString(if (on) R.string.hide_floating else R.string.show_floating)
    }

    private fun toggleFloating() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_CLOSE))
            updateFloatingButton(false)
            return
        }
        if (!ModelManager.isInstalled(this)) {
            toast("Please download the speech model first.")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Allow display over other apps")
                .setMessage("To show the record button and the live text on top of your video, " +
                    "Android needs the permission \"Appear on top\" (\"Display over other apps\").\n\n" +
                    "On the next screen, switch it ON for VidSubVoskE, then come back.")
                .setPositiveButton("Open settings") { _, _ ->
                    wantFloating = true
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        startFloating()
    }

    private fun startFloating() {
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        updateFloatingButton(true)
        toast("Floating button is on. Open your video and tap the button.")
        moveTaskToBack(true)
    }

    // ---------- Recording ----------

    private fun onRecordClicked() {
        if (LiveState.isRecording.value) {
            startService(Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP))
            return
        }
        if (!ModelManager.isInstalled(this)) {
            toast("Please download the speech model first.")
            return
        }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) askCapturePermission() else permLauncher.launch(missing.toTypedArray())
    }

    private fun hasMicPermission() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askCapturePermission() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            // Ask for the whole screen so audio from every app can be captured
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            mpm.createScreenCaptureIntent()
        }
        captureLauncher.launch(intent)
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    LiveState.isRecording.collect { rec ->
                        btnRecord.text = getString(if (rec) R.string.stop_recording else R.string.start_recording)
                        btnRecord.setBackgroundColor(ContextCompat.getColor(this@MainActivity,
                            if (rec) R.color.record_red else R.color.brand))
                    }
                }
                launch { LiveState.status.collect { tvStatus.text = it } }
                launch {
                    combine(LiveState.elapsedSec, LiveState.lagSec) { s, lag -> s to lag }
                        .collect { (s, lag) ->
                            val t = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
                            tvTimer.text = if (lag >= 1.5f)
                                String.format(Locale.US, "%s  (text +%.0f s)", t, lag) else t
                        }
                }
                launch {
                    LiveState.error.collect { e ->
                        if (e != null) {
                            LiveState.error.value = null
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle("Problem")
                                .setMessage(e)
                                .setPositiveButton("OK", null)
                                .show()
                        }
                    }
                }
                launch {
                    combine(LiveState.finalText, LiveState.partial) { f, p -> f to p }
                        .collect { (f, p) -> showTranscript(f, p) }
                }
            }
        }
    }

    private fun showTranscript(final: String, partial: String) {
        val sb = SpannableStringBuilder(final)
        if (partial.isNotEmpty()) {
            if (sb.isNotEmpty()) sb.append("\n")
            val start = sb.length
            sb.append(partial).append(" …")
            sb.setSpan(ForegroundColorSpan(ContextCompat.getColor(this, R.color.partial_gray)),
                start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(StyleSpan(Typeface.ITALIC), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        tvTranscript.text = sb
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyText() {
        val text = LiveState.finalText.value
        if (text.isBlank()) { toast("No text yet."); return }
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Transcript", text))
        toast("Text copied.")
    }

    // ---------- Speech model ----------

    private fun refreshModelCard() {
        cardModel.visibility = if (ModelManager.isInstalled(this)) View.GONE else View.VISIBLE
    }

    private fun installModel(work: suspend () -> Unit) {
        if (modelBusy) return
        modelBusy = true
        btnDownload.isEnabled = false
        btnImport.isEnabled = false
        progressModel.visibility = View.VISIBLE
        progressModel.isIndeterminate = true
        lifecycleScope.launch {
            try {
                work()
                toast("Speech model installed.")
            } catch (e: Exception) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Model not installed")
                    .setMessage((e.message ?: e.toString()) +
                        "\n\nYou can also download the file on a computer:\n${ModelManager.MODEL_URL}\n" +
                        "then copy it to the phone and use \"Import zip\".")
                    .setPositiveButton("OK", null)
                    .show()
            } finally {
                modelBusy = false
                btnDownload.isEnabled = true
                btnImport.isEnabled = true
                progressModel.visibility = View.GONE
                tvModelStatus.text = getString(R.string.model_missing)
                refreshModelCard()
            }
        }
    }

    private suspend fun downloadModel() = withContext(Dispatchers.IO) {
        ModelManager.download(applicationContext) { p ->
            runOnUiThread {
                if (p >= 0) {
                    progressModel.isIndeterminate = false
                    progressModel.progress = p
                    tvModelStatus.text = if (p < 100) "Downloading speech model… $p%" else "Installing…"
                } else {
                    tvModelStatus.text = "Downloading speech model…"
                }
            }
        }
    }

    private suspend fun importFrom(uri: Uri) = withContext(Dispatchers.IO) {
        runOnUiThread { tvModelStatus.text = "Installing…" }
        val input = contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Could not open the file")
        input.use { ModelManager.install(applicationContext, it) }
    }

    // ---------- Menu ----------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.menu_close -> { closeApp(); true }
        R.id.menu_recordings -> {
            startActivity(Intent(this, RecordingsActivity::class.java)); true
        }
        R.id.menu_about -> { showAbout(); true }
        else -> super.onOptionsItemSelected(item)
    }

    private fun showAbout() {
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (_: Exception) { "1.2" }
        val v = layoutInflater.inflate(R.layout.dialog_about, null)
        v.findViewById<TextView>(R.id.tvAboutTitle).text = "${getString(R.string.app_name)}  v$version"
        v.findViewById<TextView>(R.id.tvAboutBody).text =
            "Records the sound playing on your phone (for example from a video) " +
            "and writes live English text while it plays. Works offline.\n\n" +
            "Tip: tap \"Show floating button\" to record and see the text right over your video. " +
            "Long-press the floating button for options.\n\n" +
            "Developed by\nDr.-Eng. Moaid Subh\n" +
            "Subh Engineering\n" +
            "Software.dr.subh@gmail.com\n\n" +
            "Speech recognition: Vosk by Alpha Cephei (Apache 2.0 licence)."
        AlertDialog.Builder(this)
            .setView(v)
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------- New / Close ----------

    /** Clears the screen for a new recording (stops and saves the current one first). */
    private fun newSession() {
        if (!LiveState.isRecording.value) {
            clearScreen(); return
        }
        AlertDialog.Builder(this)
            .setTitle("Start new?")
            .setMessage("The current recording will be stopped and saved, and the screen cleared.")
            .setPositiveButton("New") { _, _ ->
                stopRecordingThen { clearScreen() }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearScreen() {
        LiveState.reset()
        LiveState.status.value = "Ready for a new recording"
        toast("Ready. Tap Start recording or the floating button.")
    }

    /** Stops everything (recording + floating button) and closes the app. */
    private fun closeApp() {
        val doClose = {
            stopRecordingThen {
                if (OverlayService.running) {
                    startService(Intent(this, OverlayService::class.java)
                        .setAction(OverlayService.ACTION_CLOSE))
                }
                LiveState.reset()
                LiveState.status.value = "Ready"
                finishAndRemoveTask()
            }
        }
        if (LiveState.isRecording.value) {
            AlertDialog.Builder(this)
                .setTitle("Close the app?")
                .setMessage("The current recording will be stopped and saved.")
                .setPositiveButton("Close") { _, _ -> doClose() }
                .setNegativeButton("Cancel", null)
                .show()
        } else doClose()
    }

    private fun stopRecordingThen(after: () -> Unit) {
        if (!LiveState.isRecording.value) { after(); return }
        startService(Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP))
        lifecycleScope.launch {
            // wait until the text is finished and the files are saved
            withTimeoutOrNull(15000) { LiveState.isRecording.first { !it } }
            after()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
