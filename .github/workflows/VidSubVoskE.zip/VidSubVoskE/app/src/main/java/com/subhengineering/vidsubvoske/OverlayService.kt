package com.subhengineering.vidsubvoske

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Floating record button + subtitle strip drawn over other apps (videos).
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_CLOSE = "com.subhengineering.vidsubvoske.OVERLAY_CLOSE"
        private const val CHANNEL_ID = "floating"
        private const val NOTIF_ID = 2
        private val SIZES = intArrayOf(14, 17, 20, 24, 28)
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }

    private var bubble: FrameLayout? = null
    private lateinit var bubbleIcon: ImageView
    private lateinit var bubbleBg: GradientDrawable
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private var caption: FrameLayout? = null
    private lateinit var captionText: TextView
    private lateinit var captionParams: WindowManager.LayoutParams

    private var captionsOn: Boolean
        get() = prefs.getBoolean("captions", true)
        set(v) { prefs.edit().putBoolean("captions", v).apply() }

    private var textSize: Int
        get() = prefs.getInt("size", 20)
        set(v) { prefs.edit().putInt("size", v).apply() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WindowManager::class.java)
        goForeground()
        addCaption()
        addBubble()
        observe()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CLOSE) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        handler.removeCallbacksAndMessages(null)
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        caption?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; caption = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT)

    // ---------------- Floating button ----------------

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val size = dp(60)
        bubbleBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(getColor(R.color.brand))
            setStroke(dp(2), Color.WHITE)
        }
        bubbleIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_mic)
            val p = dp(14); setPadding(p, p, p, p)
        }
        val view = FrameLayout(this).apply {
            background = bubbleBg
            elevation = dp(6).toFloat()
            addView(bubbleIcon, FrameLayout.LayoutParams(size, size))
        }
        val screenW = resources.displayMetrics.widthPixels
        bubbleParams = overlayParams(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("bx", screenW - size - dp(12))
            y = prefs.getInt("by", dp(220))
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0; var startY = 0
        var downX = 0f; var downY = 0f
        var moved = false; var longFired = false
        val longPress = Runnable { longFired = true; showMenu() }

        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = bubbleParams.x; startY = bubbleParams.y
                    downX = e.rawX; downY = e.rawY
                    moved = false; longFired = false
                    handler.postDelayed(longPress, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true; handler.removeCallbacks(longPress)
                    }
                    if (moved) {
                        bubbleParams.x = startX + dx.toInt()
                        bubbleParams.y = startY + dy.toInt()
                        try { wm.updateViewLayout(view, bubbleParams) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (moved) {
                        prefs.edit().putInt("bx", bubbleParams.x).putInt("by", bubbleParams.y).apply()
                    } else if (!longFired) {
                        onBubbleTap()
                    }
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
            }
            true
        }
        wm.addView(view, bubbleParams)
        bubble = view
    }

    private fun onBubbleTap() {
        if (LiveState.isRecording.value) {
            startService(Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP))
        } else {
            startActivity(Intent(this, CaptureActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        }
    }

    private fun showMenu() {
        val items = arrayOf(
            if (captionsOn) "Hide live text" else "Show live text",
            "Text size: ${textSize}  (tap to change)",
            "Open the app",
            "Close floating button"
        )
        val dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(getString(R.string.app_name))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> { captionsOn = !captionsOn; refreshCaption() }
                    1 -> {
                        val i = SIZES.indexOf(textSize)
                        textSize = SIZES[(i + 1) % SIZES.size]
                        captionText.textSize = textSize.toFloat()
                        toast("Text size $textSize")
                    }
                    2 -> startActivity(Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    3 -> stopSelf()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()
        dlg.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        try { dlg.show() } catch (e: Exception) { toast("Cannot open menu: ${e.message}") }
    }

    // ---------------- Subtitle strip ----------------

    @SuppressLint("ClickableViewAccessibility")
    private fun addCaption() {
        captionText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = this@OverlayService.textSize.toFloat()
            gravity = Gravity.CENTER
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            maxLines = 4
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xB3000000.toInt())
            }
        }
        val view = FrameLayout(this).apply {
            setPadding(dp(10), 0, dp(10), 0)
            addView(captionText, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT))
            visibility = View.GONE
        }
        captionParams = overlayParams(WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = prefs.getInt("cy", dp(120))
        }

        // Drag the strip up / down
        var startY = 0; var downY = 0f
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startY = captionParams.y; downY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    captionParams.y = (startY - (e.rawY - downY)).toInt().coerceAtLeast(0)
                    try { wm.updateViewLayout(view, captionParams) } catch (_: Exception) {}
                }
                MotionEvent.ACTION_UP -> prefs.edit().putInt("cy", captionParams.y).apply()
            }
            true
        }
        wm.addView(view, captionParams)
        caption = view
    }

    private fun observe() {
        scope.launch {
            LiveState.isRecording.collect { rec ->
                bubbleBg.setColor(getColor(if (rec) R.color.record_red else R.color.brand))
                bubbleIcon.setImageResource(if (rec) R.drawable.ic_stop else R.drawable.ic_mic)
                refreshCaption()
            }
        }
        scope.launch {
            combine(LiveState.finalText, LiveState.partial, LiveState.lagSec) { f, p, lag ->
                buildCaption(f, p, lag)
            }.collect { captionText.text = it }
        }
        scope.launch {
            LiveState.error.collect { e -> if (e != null) toast(e) }
        }
    }

    private fun refreshCaption() {
        caption?.visibility =
            if (LiveState.isRecording.value && captionsOn) View.VISIBLE else View.GONE
    }

    private fun buildCaption(final: String, partial: String, lag: Float): CharSequence {
        val stamp = Regex("^\\[\\d+:\\d+]\\s*")
        val lines = final.lines().filter { it.isNotBlank() }.map { it.replace(stamp, "") }
            .takeLast(if (partial.isEmpty()) 2 else 1)
        val sb = SpannableStringBuilder(lines.joinToString("\n"))
        if (partial.isNotEmpty()) {
            val p = if (partial.length > 140) "…" + partial.takeLast(140) else partial
            if (sb.isNotEmpty()) sb.append("\n")
            val s = sb.length
            sb.append(p)
            sb.setSpan(ForegroundColorSpan(0xFFDDDDDD.toInt()), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(StyleSpan(Typeface.ITALIC), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (sb.isEmpty()) sb.append("Listening…")
        if (lag >= 1.5f) {
            val s = sb.length
            sb.append(String.format(java.util.Locale.US, "  (+%.0f s)", lag))
            sb.setSpan(ForegroundColorSpan(0xFFFFC107.toInt()), s, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    // ---------------- Notification ----------------

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "Floating button", NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(this, 10,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val close = PendingIntent.getService(this, 11,
            Intent(this, OverlayService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Floating record button is on")
            .setContentText("Tap the button over your video to record")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Close", close)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
