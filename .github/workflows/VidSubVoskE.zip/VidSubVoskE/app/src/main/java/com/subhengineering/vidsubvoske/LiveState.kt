package com.subhengineering.vidsubvoske

import kotlinx.coroutines.flow.MutableStateFlow

/** Shared state between the recording service and the screen. */
object LiveState {
    val isRecording = MutableStateFlow(false)
    val status = MutableStateFlow("Ready")
    val finalText = MutableStateFlow("")
    val partial = MutableStateFlow("")
    val elapsedSec = MutableStateFlow(0L)
    val error = MutableStateFlow<String?>(null)
    /** How many seconds the text is behind the sound. */
    val lagSec = MutableStateFlow(0f)

    fun reset() {
        finalText.value = ""
        partial.value = ""
        elapsedSec.value = 0L
        error.value = null
        lagSec.value = 0f
    }

    fun appendLine(line: String) {
        val cur = finalText.value
        finalText.value = if (cur.isEmpty()) line else "$cur\n$line"
    }
}
