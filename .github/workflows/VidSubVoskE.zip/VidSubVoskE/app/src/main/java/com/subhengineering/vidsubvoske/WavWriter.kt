package com.subhengineering.vidsubvoske

import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile

/** Writes 16-bit mono PCM to a WAV file; the header is fixed on close. */
class WavWriter(private val file: File, private val sampleRate: Int) {
    private val out = FileOutputStream(file)
    private var dataBytes = 0L

    init {
        out.write(ByteArray(44)) // placeholder header
    }

    fun write(buf: ByteArray, len: Int) {
        out.write(buf, 0, len)
        dataBytes += len
    }

    fun close() {
        try { out.flush(); out.close() } catch (_: Exception) {}
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            raf.write(header(dataBytes))
        }
    }

    private fun header(dataLen: Long): ByteArray {
        val channels = 1
        val bits = 16
        val byteRate = sampleRate * channels * bits / 8
        val h = ByteArray(44)
        fun str(o: Int, s: String) = s.forEachIndexed { i, c -> h[o + i] = c.code.toByte() }
        fun i32(o: Int, v: Long) { for (i in 0 until 4) h[o + i] = ((v shr (8 * i)) and 0xFF).toByte() }
        fun i16(o: Int, v: Int) { h[o] = (v and 0xFF).toByte(); h[o + 1] = ((v shr 8) and 0xFF).toByte() }
        str(0, "RIFF"); i32(4, 36 + dataLen); str(8, "WAVE")
        str(12, "fmt "); i32(16, 16); i16(20, 1); i16(22, channels)
        i32(24, sampleRate.toLong()); i32(28, byteRate.toLong())
        i16(32, channels * bits / 8); i16(34, bits)
        str(36, "data"); i32(40, dataLen)
        return h
    }
}
