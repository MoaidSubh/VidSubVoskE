package com.subhengineering.vidsubvoske

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SimpleAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class RecordingsActivity : AppCompatActivity() {

    private data class Rec(val base: String, val wav: File, val txt: File)

    private lateinit var list: ListView
    private lateinit var tvEmpty: TextView
    private var items: List<Rec> = emptyList()
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recordings)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        list = findViewById(R.id.list)
        tvEmpty = findViewById(R.id.tvEmpty)
        list.setOnItemClickListener { _, _, pos, _ -> showOptions(items[pos]) }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    override fun onDestroy() {
        stopPlayer()
        super.onDestroy()
    }

    private fun load() {
        val dir = Storage.dir(this)
        items = (dir.listFiles() ?: emptyArray())
            .filter { it.extension == "wav" || it.extension == "txt" }
            .map { it.nameWithoutExtension }
            .distinct()
            .sortedDescending()
            .map { Rec(it, File(dir, "$it.wav"), File(dir, "$it.txt")) }

        val inFmt = SimpleDateFormat("'Rec_'yyyyMMdd_HHmmss", Locale.US)
        val outFmt = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.US)
        val rows = items.map { r ->
            val title = try { outFmt.format(inFmt.parse(r.base)!!) } catch (_: Exception) { r.base }
            val secs = if (r.wav.exists()) (r.wav.length() - 44).coerceAtLeast(0) / 32000 else 0L
            val dur = String.format(Locale.US, "%d:%02d", secs / 60, secs % 60)
            val preview = if (r.txt.exists()) firstLine(r.txt) else ""
            mapOf("t" to title, "s" to "$dur   $preview")
        }
        list.adapter = SimpleAdapter(this, rows, android.R.layout.simple_list_item_2,
            arrayOf("t", "s"), intArrayOf(android.R.id.text1, android.R.id.text2))
        tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun firstLine(f: File): String = try {
        f.readLines().drop(3).firstOrNull { it.isNotBlank() }?.take(60) ?: "(no speech found)"
    } catch (_: Exception) { "" }

    private fun showOptions(r: Rec) {
        val opts = arrayOf("Read text", "Play audio", "Share text", "Share audio", "Rename", "Delete")
        AlertDialog.Builder(this)
            .setTitle(r.base)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> readText(r)
                    1 -> play(r)
                    2 -> share(r.txt, "text/plain")
                    3 -> share(r.wav, "audio/wav")
                    4 -> rename(r)
                    5 -> delete(r)
                }
            }
            .show()
    }

    private fun readText(r: Rec) {
        val text = if (r.txt.exists()) r.txt.readText() else "No text file."
        val tv = TextView(this).apply {
            this.text = text
            setTextIsSelectable(true)
            textSize = 16f
            setPadding(48, 24, 48, 24)
        }
        val sv = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this)
            .setTitle(r.base)
            .setView(sv)
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy") { _, _ ->
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("Transcript", text))
                toast("Text copied.")
            }
            .setNegativeButton("Share") { _, _ -> share(r.txt, "text/plain") }
            .show()
    }

    private fun play(r: Rec) {
        if (!r.wav.exists()) { toast("No audio file."); return }
        stopPlayer()
        try {
            player = MediaPlayer().apply {
                setDataSource(r.wav.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) {
            toast("Cannot play: ${e.message}"); return
        }
        AlertDialog.Builder(this)
            .setTitle("Playing")
            .setMessage(r.base)
            .setPositiveButton("Stop", null)
            .setOnDismissListener { stopPlayer() }
            .show()
    }

    private fun stopPlayer() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
    }

    private fun share(f: File, mime: String) {
        if (!f.exists()) { toast("File not found."); return }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            if (mime == "text/plain") putExtra(Intent.EXTRA_TEXT, f.readText())
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share"))
    }

    private fun rename(r: Rec) {
        val input = EditText(this).apply {
            setText(r.base)
            inputType = InputType.TYPE_CLASS_TEXT
            setSelection(text.length)
        }
        val box = FrameLayout(this).apply {
            setPadding(48, 16, 48, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle("Rename")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val name = input.text.toString().trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (name.isEmpty() || name == r.base) return@setPositiveButton
                val dir = r.wav.parentFile ?: return@setPositiveButton
                if (File(dir, "$name.wav").exists() || File(dir, "$name.txt").exists()) {
                    toast("That name already exists."); return@setPositiveButton
                }
                if (r.wav.exists()) r.wav.renameTo(File(dir, "$name.wav"))
                if (r.txt.exists()) r.txt.renameTo(File(dir, "$name.txt"))
                load()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun delete(r: Rec) {
        AlertDialog.Builder(this)
            .setTitle("Delete recording?")
            .setMessage("${r.base}\n\nThe audio and the text will be deleted.")
            .setPositiveButton("Delete") { _, _ ->
                r.wav.delete(); r.txt.delete(); load()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
