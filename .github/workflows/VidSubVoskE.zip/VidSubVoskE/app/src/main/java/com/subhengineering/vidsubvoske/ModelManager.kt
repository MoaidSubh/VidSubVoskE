package com.subhengineering.vidsubvoske

import android.content.Context
import org.vosk.Model
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads / installs / loads the Vosk English model. */
object ModelManager {
    const val MODEL_NAME = "vosk-model-small-en-us-0.15"
    const val MODEL_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"

    @Volatile private var model: Model? = null

    private fun modelDir(ctx: Context) = File(ctx.filesDir, "model")

    fun isInstalled(ctx: Context): Boolean {
        val d = modelDir(ctx)
        return File(d, "am").isDirectory && File(d, "conf").isDirectory
    }

    /** Loads the model once and keeps it in memory. Call from a background thread. */
    @Synchronized
    fun get(ctx: Context): Model {
        model?.let { return it }
        if (!isInstalled(ctx)) throw IllegalStateException("Speech model is not installed")
        return Model(modelDir(ctx).absolutePath).also { model = it }
    }

    /** Blocking download + install. onProgress gets 0..100 (or -1 if size unknown). */
    fun download(ctx: Context, onProgress: (Int) -> Unit) {
        val zip = File(ctx.cacheDir, "model.zip")
        var conn: HttpURLConnection? = null
        try {
            var url = URL(MODEL_URL)
            // Follow redirects manually (also across http/https)
            var redirects = 0
            while (true) {
                conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000
                    readTimeout = 30000
                    instanceFollowRedirects = false
                }
                val code = conn.responseCode
                if (code in 300..399 && redirects < 5) {
                    val loc = conn.getHeaderField("Location") ?: break
                    url = URL(url, loc); conn.disconnect(); redirects++
                    continue
                }
                if (code != 200) throw IllegalStateException("Download failed (HTTP $code)")
                break
            }
            val c = conn!!
            val total = c.contentLengthLong
            c.inputStream.use { input ->
                FileOutputStream(zip).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -2
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val p = if (total > 0) (done * 100 / total).toInt() else -1
                        if (p != last) { last = p; onProgress(p) }
                    }
                }
            }
        } finally {
            conn?.disconnect()
        }
        zip.inputStream().use { install(ctx, it) }
        zip.delete()
    }

    /** Installs a model from a zip stream (downloaded or picked by the user). */
    @Synchronized
    fun install(ctx: Context, zipStream: InputStream) {
        val tmp = File(ctx.filesDir, "model_tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        val tmpCanon = tmp.canonicalPath + File.separator
        ZipInputStream(zipStream.buffered()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                val f = File(tmp, e.name)
                if (!f.canonicalPath.startsWith(tmpCanon)) continue // zip-slip guard
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { zis.copyTo(it) }
                }
            }
        }
        val root = findModelRoot(tmp) ?: run {
            tmp.deleteRecursively()
            throw IllegalStateException("This zip is not a Vosk model")
        }
        model?.close(); model = null
        val dest = modelDir(ctx)
        dest.deleteRecursively()
        if (!root.renameTo(dest)) {
            root.copyRecursively(dest, overwrite = true)
        }
        tmp.deleteRecursively()
    }

    private fun findModelRoot(dir: File, depth: Int = 0): File? {
        if (File(dir, "am").isDirectory && File(dir, "conf").isDirectory) return dir
        if (depth >= 3) return null
        dir.listFiles()?.filter { it.isDirectory }?.forEach { sub ->
            findModelRoot(sub, depth + 1)?.let { return it }
        }
        return null
    }
}
